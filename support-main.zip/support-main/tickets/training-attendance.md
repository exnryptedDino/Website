---
layout: default
title: Training Attendance
parent: Tickets
nav_order: 2
---


# Training Attendance
When submitting training attendance in tickets the below format should be used.  

## Training Attendance Format:
{:.text-red-300}

__mm/dd/yyyy @ x PM EST Training Session Attendance__  

__Host:__ (username)  
__Co-Host:__ (username)  

__Store Manager:__  
(list names)  

__Store Director:__  
(list names)  

__Board of Directors:__  
(list names)  

__Executive Assistant:__  
(list names)  

__Store Executive:__  
(list names)  
