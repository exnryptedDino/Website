---
layout: default
title: Shift & Training Times
parent: Staff Information
nav_order: 3
---

# Shift & Training Times
Here you will find all session times that occur at BloxStreet and the Training Center.

| Shift Times | 
|:------------| 
| 12 AM EST | 
| 7 AM EST |
| 9 AM EST |
| 11 AM EST |
| 1 PM EST |
| 3 PM EST |
| 6 PM EST |
| 8 PM EST (not hosted on Fridays) |
| 10 PM EST |


| Training Times | 
|:------------| 
| 6 AM EST |
| 8 AM EST |
| 10 AM EST |
| 12 PM EST |
| 2 PM EST |
| 4 PM EST |
| 7 PM EST |
| 9 PM EST |
| 11 PM EST |
