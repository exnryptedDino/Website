---
layout: default
title: HR Information
nav_order: 7
has_children: true
permalink: /hr-information
---

# HR Information

This guide is intended for high ranks.
Below is some important information you need to know as an HR.
