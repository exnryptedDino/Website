---
layout: default
title: Conduct
parent: HR Information
nav_order: 1
---

# Conduct as an HR

## Conduct in BloxStreet Games
{:.text-red-300}

*  While in a BloxStreet game, behavior matters! Acting unprofessionally has a bad look on our group and HR team.
*  All HRs are expected to utilize proper grammar on BloxStreet games.
*  All HRs are expected to behave professionally. 
*  All HRs are expected to handle situations calmly and to the best of their abilities.
*  HRs should not have off-topic conversations while in a BloxStreet game. You have direct messages and chats for that.
*  HRs may not abuse any special permissions (i.e. announcement feature).
*  These rules apply to public and private servers.


## Rule Breaking at Other Establishments
{:.text-red-300}

Please remember that trolling, exploiting, or some sort of rule breaking at other establishments, no matter if it’s an alliance group or not, will not be tolerated. If you’re caught doing so, you will be punished. You have to follow all rules and regulations when joining Roblox games other than BloxStreet games. Please remember to behave, as it could damage our group’s reputation when breaking rules at other establishments.
