---
layout: default
title: Rank Purchasing
parent: HR Information
nav_order: 3
---

# Rank Purchasing

*  If someone DMs you saying they purchased a rank, do not rank them.
*  Inform them to create a ticket.
*  Ranking the player or/and dealing with this type of situation results in consequences.
