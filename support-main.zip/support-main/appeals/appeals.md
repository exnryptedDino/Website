---
layout: default
title: Appeals
nav_order: 6
has_children: true
permalink: /appeals
---

# Appeals 
This section contains information regarding all appeals made for blacklists, permanent bans, and Discord bans.
